//
//  ZXNavTitleView.h
//  ZXNavigationBar
//
//  Created by 李兆祥 on 2020/3/12.
//  Copyright © 2020 ZXLee. All rights reserved.
//  https://github.com/SmileZXLee/ZXNavigationBar

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ZXNavTitleView : UIView

@end

NS_ASSUME_NONNULL_END
