//
//  DemoFoldXibViewController.h
//  ZXNavigationBarDemo
//
//  Created by 李兆祥 on 2020/3/13.
//  Copyright © 2020 ZXLee. All rights reserved.
//

#import "DemoBaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface DemoFoldXibViewController : DemoBaseViewController

@end

NS_ASSUME_NONNULL_END
