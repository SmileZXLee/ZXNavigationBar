//
//  DemoXibViewController.m
//  ZXNavigationBarDemo
//
//  Created by 李兆祥 on 2020/3/10.
//  Copyright © 2020 ZXLee. All rights reserved.
//

#import "DemoXibViewController.h"
#import "DemoSystemBarViewController.h"
@interface DemoXibViewController ()
///是否禁止pop操作
@property(assign, nonatomic)BOOL disablePop;
@end

@implementation DemoXibViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //设置导航栏标题
    self.title = @"ZXNavigationBar";
    
    //设置最右侧的Button的图片和点击回调
    [self zx_setRightBtnWithImgName:@"set_icon" clickedBlock:^(UIButton * _Nonnull btn) {
        NSLog(@"点击了最右侧的Button");
    }];
    self.zx_backBtnImageName = @"set_icon";
    
    //最左侧的按钮添加”返回“文字，当当前控制器不是第0个的时候，ZXNavigationBar会自动显示返回图片，且点击返回上一个控制器
    //[self.zx_navLeftBtn setTitle:@"返回" forState:UIControlStateNormal];
    
    __weak typeof(self) weakSelf = self;
    self.zx_handlePopBlock = ^BOOL(ZXNavigationBarController * _Nonnull viewController, ZXNavPopBlockFrom popBlockFrom) {
        return !weakSelf.disablePop;
    };
}

#pragma mark - Actions

#pragma mark 点击了设置背景色橙色
- (IBAction)changeBacColorAction:(UISwitch *)sender {
    if(sender.on){
        self.zx_navBarBackgroundColor = [UIColor orangeColor];
    }else{
        self.zx_navBarBackgroundColor = [UIColor whiteColor];
    }
}

#pragma mark 点击了设置背景图片
- (IBAction)setBacImageAction:(UISwitch *)sender {
    if(sender.on){
        self.zx_navBarBackgroundImage = [UIImage imageNamed:@"nav_bac"];
    }else{
        self.zx_navBarBackgroundImage = nil;
    }
}

#pragma mark 点击了设置TintColor黄色
- (IBAction)ChangeTintColorAction:(UISwitch *)sender {
    if(sender.on){
        self.zx_navTintColor = [UIColor yellowColor];
    }else{
        self.zx_navTintColor = [UIColor blackColor];
    }
}

#pragma mark 点击了设置大小标题效果
- (IBAction)setBigSubTitleAction:(UISwitch *)sender {
    if(sender.on){
        [self zx_setMultiTitle:@"ZXNavigationBar" subTitle:@"subTitle"];
    }else{
        self.title = @"ZXNavigationBar";
    }
}

#pragma mark 点击了设置StatusBar白色
- (IBAction)changeStatusBarAction:(UISwitch *)sender {
    if(sender.on){
        self.zx_navStatusBarStyle = ZXNavStatusBarStyleLight;
        [self.zx_navLeftBtn setImage:nil forState:UIControlStateNormal];
        [self.zx_navLeftBtn setTitle:@"取消权限" forState:UIControlStateNormal];
    }else{
        self.zx_navStatusBarStyle = ZXNavStatusBarStyleDefault;
        [self.zx_navLeftBtn setTitle:nil forState:UIControlStateNormal];
        [self.zx_navLeftBtn setImage:[UIImage imageNamed:@"set_icon"] forState:UIControlStateNormal];
        
    }
}

#pragma mark 点击了设置两边Item大小为30
- (IBAction)changeItemSizeAction:(UISwitch *)sender {
    if(sender.on){
        self.zx_navItemSize = 30;
    }else{
        self.zx_navItemSize = ZXNavDefalutItemSize;
    }
}

#pragma mark 点击了设置两边Item边距为0
- (IBAction)changeItemMarginAction:(UISwitch *)sender {
    if(sender.on){
        self.zx_navItemMargin = 0;
    }else{
        self.zx_navItemMargin = ZXNavDefalutItemMargin;
    }
}

#pragma mark 点击了设置渐变背景
- (IBAction)changeGradientBacAction:(UISwitch *)sender {
    if(sender.on){
        [self zx_setNavGradientBacFrom:[UIColor magentaColor] to:[UIColor cyanColor]];
    }else{
        [self zx_removeNavGradientBac];
    }
    
}

#pragma mark 点击了更换为系统的导航栏
- (IBAction)changeSystemNavBarAction:(UISwitch *)sender {
    if(sender.on){
        self.zx_showSystemNavBar = YES;
    }else{
        self.zx_showSystemNavBar = NO;
        self.zx_hideBaseNavBar = NO;
    }
    
}

#pragma mark 点击了右侧显示两个Item
- (IBAction)changeRightSubBtnAction:(UISwitch *)sender {
    if(sender.on){
        //设置自定义NavItemView
        self.zx_navSubRightBtn.zx_customView = [UISwitch new];
    }else{
        self.zx_navSubRightBtn.zx_customView = nil;
    }
}

- (IBAction)disPopAction:(UISwitch *)sender {
    self.disablePop = sender.on;
}

@end
